
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { PrismaClient } from '@prisma/client';
import authRouter from './routes/auth.js';
import taskRouter from './routes/tasks.js';
import projectRouter from './routes/projects.js';
import syncRouter from './routes/sync.js';
import meRouter from './routes/me.js';

const prisma = new PrismaClient();
const app = express();

app.use(helmet());
app.use(cors({ origin: '*' }));
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

app.use('/auth', authRouter);
app.use('/tasks', taskRouter);
app.use('/projects', projectRouter);
app.use('/sync', syncRouter);
app.use('/me', meRouter);

const port = process.env.PORT ? Number(process.env.PORT) : 4000;
app.listen(port, () => { console.log(`API running on http://localhost:${port}`); });
