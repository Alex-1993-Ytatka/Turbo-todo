
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { auth } from './auth-mw.js';

const prisma = new PrismaClient();
const router = Router();

const schema = z.object({ name: z.string().min(1) });

router.get('/', auth, async (req:any, res) => {
  const projects = await prisma.project.findMany({ where: { ownerId: req.userId } });
  res.json(projects);
});

router.post('/', auth, async (req:any, res) => {
  try {
    const data = schema.parse(req.body);
    const project = await prisma.project.create({ data: { ...data, ownerId: req.userId } });
    res.json(project);
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});

export default router;
