
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { auth } from './auth-mw.js';

const prisma = new PrismaClient();
const router = Router();

// GET /sync?since=ISO — выгрузка изменений
router.get('/', auth, async (req:any, res) => {
  const since = req.query.since ? new Date(String(req.query.since)) : new Date(0);
  const tasks = await prisma.task.findMany({ where: { ownerId: req.userId, updatedAt: { gt: since } } });
  res.json({ tasks, ts: new Date().toISOString() });
});

// POST /sync — приём изменений с клиента (upsert по id)
router.post('/', auth, async (req:any, res) => {
  const items = Array.isArray(req.body?.tasks) ? req.body.tasks : [];
  const results:any[] = [];
  for (const t of items) {
    if (!t.id) continue;
    const data:any = {
      title: t.title ?? 'Untitled',
      description: t.description ?? null,
      done: !!t.done,
      dueDate: t.dueDate ? new Date(t.dueDate) : null,
      deleted: !!t.deleted,
      ownerId: req.userId,
      updatedAt: t.updatedAt ? new Date(t.updatedAt) : new Date()
    };
    const exists = await prisma.task.findUnique({ where: { id: t.id } });
    if (exists) {
      const updated = await prisma.task.update({ where: { id: t.id }, data });
      results.push(updated);
    } else {
      const created = await prisma.task.create({ data: { ...data, id: t.id } });
      results.push(created);
    }
  }
  res.json({ ok: true, count: results.length });
});

export default router;
