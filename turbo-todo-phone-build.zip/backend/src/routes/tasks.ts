
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { auth } from './auth-mw.js';

const prisma = new PrismaClient();
const router = Router();

const taskSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  dueDate: z.string().datetime().optional(),
  projectId: z.string().optional()
});

router.get('/', auth, async (req:any, res) => {
  const tasks = await prisma.task.findMany({ where: { ownerId: req.userId, deleted: false }, orderBy: { createdAt: 'desc' } });
  res.json(tasks);
});

router.post('/', auth, async (req:any, res) => {
  try {
    const data = taskSchema.parse(req.body);
    const task = await prisma.task.create({ data: { ...data, ownerId: req.userId } });
    await prisma.user.update({ where: { id: req.userId }, data: { points: { increment: 1 } } });
    res.json(task);
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});

router.patch('/:id', auth, async (req:any, res) => {
  try {
    const id = req.params.id;
    const task = await prisma.task.update({ where: { id }, data: { ...req.body } });
    res.json(task);
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});

router.post('/:id/toggle', auth, async (req:any, res) => {
  try {
    const id = req.params.id;
    const task = await prisma.task.findUnique({ where: { id } });
    if (!task) return res.status(404).json({ error: 'Not found' });
    const updated = await prisma.task.update({ where: { id }, data: { done: !task.done } });
    if (!task.done) {
      await prisma.user.update({ where: { id: task.ownerId }, data: { points: { increment: 5 }, streak: { increment: 1 }, lastDone: new Date() } });
    }
    res.json(updated);
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});

router.delete('/:id', auth, async (req:any, res) => {
  try {
    const id = req.params.id;
    await prisma.task.update({ where: { id }, data: { deleted: true } });
    res.json({ ok: true });
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});

export default router;
