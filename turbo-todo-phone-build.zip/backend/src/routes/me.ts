
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { auth } from './auth-mw.js';

const prisma = new PrismaClient();
const router = Router();

router.get('/', auth, async (req:any, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  const total = await prisma.task.count({ where: { ownerId: req.userId, deleted: false } });
  const done = await prisma.task.count({ where: { ownerId: req.userId, deleted: false, done: true } });
  res.json({ points: user?.points ?? 0, streak: user?.streak ?? 0, totals: { total, done } });
});

export default router;
