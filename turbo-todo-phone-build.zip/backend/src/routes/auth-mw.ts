
import jwt from 'jsonwebtoken';
export function auth(req:any, res:any, next:any) {
  try {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ error: 'No token' });
    const token = header.split(' ')[1];
    const payload:any = jwt.verify(token, process.env.JWT_SECRET as string);
    req.userId = payload.sub;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}
