
import { Slot, Link } from 'expo-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { StatusBar } from 'expo-status-bar';
import { View, Text, TouchableOpacity } from 'react-native';
import '../src/i18n';
import { useState, createContext, useContext } from 'react';
import { themes } from '../src/design/tokens';

const client = new QueryClient();
type ThemeName = 'dark' | 'light';
const ThemeCtx = createContext<{theme:ThemeName,setTheme:(t:ThemeName)=>void}>({theme:'dark', setTheme:()=>{}});
export const useTheme = () => useContext(ThemeCtx);

export default function RootLayout() {
  const [theme, setTheme] = useState<ThemeName>('dark');
  const palette = themes[theme];
  return (
    <QueryClientProvider client={client}>
      <ThemeCtx.Provider value={{theme, setTheme}}>
        <View style={{ flex: 1, backgroundColor: palette.bg }}>
          <StatusBar style={theme === 'dark' ? 'light' : 'dark'} />
          <View style={{ padding: 12, flexDirection: 'row', justifyContent: 'space-between' }}>
            <Link href="/home"><Text style={{ color: palette.text, fontWeight: '700' }}>Turbo Todo</Text></Link>
            <View style={{ flexDirection:'row', gap: 12 }}>
              <Link href="/stats" asChild><TouchableOpacity><Text style={{ color: palette.text }}>Stats</Text></TouchableOpacity></Link>
              <Link href="/settings" asChild><TouchableOpacity><Text style={{ color: palette.text }}>Settings</Text></TouchableOpacity></Link>
            </View>
          </View>
          <Slot />
        </View>
      </ThemeCtx.Provider>
    </QueryClientProvider>
  );
}
