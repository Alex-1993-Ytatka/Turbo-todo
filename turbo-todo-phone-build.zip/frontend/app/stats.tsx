
import { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import { useTheme } from './_layout';
import { themes } from '../src/design/tokens';
import { useTranslation } from 'react-i18next';
import { API_URL, getToken } from '../src/lib/config';
import axios from 'axios';

export default function Stats() {
  const { theme } = useTheme();
  const palette = themes[theme];
  const { t } = useTranslation();
  const [data, setData] = useState<{points:number, streak:number, totals:{total:number,done:number}}|null>(null);

  useEffect(() => {
    (async () => {
      try {
        const token = await getToken();
        const res = await axios.get(`${API_URL}/me`, { headers: { Authorization: `Bearer ${token}` } });
        setData(res.data);
      } catch {}
    })();
  }, []);

  return (
    <View style={{ flex:1, backgroundColor: palette.bg, padding:16 }}>
      <Text style={{ color: palette.text, fontSize:22, fontWeight:'800', marginBottom:12 }}>{t('stats')}</Text>
      {data && (
        <View style={{ gap:12 }}>
          <View style={{ backgroundColor: palette.card, padding:16, borderRadius:12 }}>
            <Text style={{ color: palette.text }}>{t('total')}: {data.totals.total}</Text>
            <Text style={{ color: palette.text }}>{t('done')}: {data.totals.done}</Text>
          </View>
          <View style={{ backgroundColor: palette.card, padding:16, borderRadius:12 }}>
            <Text style={{ color: palette.text }}>{t('points')}: {data.points}</Text>
            <Text style={{ color: palette.text }}>{t('streak')}: {data.streak}</Text>
          </View>
        </View>
      )}
    </View>
  );
}
