
import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import axios from 'axios';
import { API_URL, setToken } from '../src/lib/config';
import { useTranslation } from 'react-i18next';
import { useTheme } from './_layout';
import { themes } from '../src/design/tokens';
export default function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();
  const { t } = useTranslation();
  const { theme } = useTheme();
  const palette = themes[theme];
  const submit = async () => {
    try {
      const { data } = await axios.post(`${API_URL}/auth/register`, { email, password });
      await setToken(data.token);
      router.replace('/home');
    } catch (e:any) {
      Alert.alert('Error', e?.response?.data?.error ?? 'Registration failed');
    }
  };
  return (
    <View style={{ flex:1, padding:24, backgroundColor:palette.bg }}>
      <Text style={{ color:palette.text, fontSize:22, fontWeight:'800', marginBottom:12 }}>{t('register')}</Text>
      <TextInput style={{ backgroundColor:palette.card, color:palette.text, padding:14, borderRadius:12, marginBottom:8 }} placeholder={t('email') as string} placeholderTextColor="#AAB" onChangeText={setEmail} autoCapitalize="none"/>
      <TextInput style={{ backgroundColor:palette.card, color:palette.text, padding:14, borderRadius:12, marginBottom:16 }} placeholder={t('password') as string} placeholderTextColor="#AAB" secureTextEntry onChangeText={setPassword}/>
      <TouchableOpacity style={{ backgroundColor:'#7AA2FF', padding:14, borderRadius:12 }} onPress={submit}><Text style={{ color:palette.bg, textAlign:'center', fontWeight:'700' }}>{t('createAccount')}</Text></TouchableOpacity>
    </View>
  );
}
