
import { Link } from 'expo-router';
import { View, Text, TouchableOpacity } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useTheme } from './_layout';
import { themes } from '../src/design/tokens';
export default function Index() {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const palette = themes[theme];
  return (
    <View style={{ flex:1, alignItems:'center', justifyContent:'center', padding:24, backgroundColor: palette.bg }}>
      <Text style={{ fontSize:28, color: palette.text, fontWeight:'800', marginBottom:8 }}>{t('appName')}</Text>
      <Text style={{ color: palette.text, opacity:0.8, marginBottom:24, textAlign:'center' }}>{t('tagline')}</Text>
      <Link href="/login" asChild><TouchableOpacity style={{ backgroundColor:'#7AA2FF', paddingHorizontal:24, paddingVertical:12, borderRadius:12 }}><Text style={{ color: palette.bg, fontWeight:'700' }}>{t('login')}</Text></TouchableOpacity></Link>
      <Link href="/register" asChild><TouchableOpacity style={{ borderColor:'#7AA2FF', borderWidth:1, paddingHorizontal:24, paddingVertical:12, borderRadius:12, marginTop:12 }}><Text style={{ color: palette.text, fontWeight:'700' }}>{t('register')}</Text></TouchableOpacity></Link>
    </View>
  );
}
