
import { View, Text, TouchableOpacity } from 'react-native';
import { useTheme } from './_layout';
import { themes } from '../src/design/tokens';
import { useTranslation } from 'react-i18next';
import i18n from '../src/i18n';
export default function Settings() {
  const { theme, setTheme } = useTheme();
  const palette = themes[theme];
  const { t } = useTranslation();
  return (
    <View style={{ flex:1, backgroundColor: palette.bg, padding:16 }}>
      <Text style={{ color: palette.text, fontSize:22, fontWeight:'800', marginBottom:12 }}>{t('settings')}</Text>
      <View style={{ backgroundColor: palette.card, padding:16, borderRadius:12, marginBottom:12 }}>
        <Text style={{ color: palette.text, marginBottom:8 }}>{t('theme')}</Text>
        <View style={{ flexDirection:'row', gap:12 }}>
          <TouchableOpacity onPress={()=>setTheme('dark')} style={{ borderWidth:1, borderColor:'#7AA2FF', paddingHorizontal:12, paddingVertical:8, borderRadius:10 }}><Text style={{ color: palette.text }}>{t('dark')}</Text></TouchableOpacity>
          <TouchableOpacity onPress={()=>setTheme('light')} style={{ borderWidth:1, borderColor:'#7AA2FF', paddingHorizontal:12, paddingVertical:8, borderRadius:10 }}><Text style={{ color: palette.text }}>{t('light')}</Text></TouchableOpacity>
        </View>
      </View>
      <View style={{ backgroundColor: palette.card, padding:16, borderRadius:12 }}>
        <Text style={{ color: palette.text, marginBottom:8 }}>{t('language')}</Text>
        <View style={{ flexDirection:'row', gap:12 }}>
          <TouchableOpacity onPress={()=>i18n.changeLanguage('ru')} style={{ borderWidth:1, borderColor:'#7AA2FF', paddingHorizontal:12, paddingVertical:8, borderRadius:10 }}><Text style={{ color: palette.text }}>Рус</Text></TouchableOpacity>
          <TouchableOpacity onPress={()=>i18n.changeLanguage('en')} style={{ borderWidth:1, borderColor:'#7AA2FF', paddingHorizontal:12, paddingVertical:8, borderRadius:10 }}><Text style={{ color: palette.text }}>EN</Text></TouchableOpacity>
          <TouchableOpacity onPress={()=>i18n.changeLanguage('uk')} style={{ borderWidth:1, borderColor:'#7AA2FF', paddingHorizontal:12, paddingVertical:8, borderRadius:10 }}><Text style={{ color: palette.text }}>Укр</Text></TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
