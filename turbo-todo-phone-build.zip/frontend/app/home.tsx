
import { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, Alert } from 'react-native';
import { getToken, API_URL, enqueue, drainQueue, getLastSyncAt, setLastSyncAt } from '../src/lib/config';
import axios from 'axios';
import { useTranslation } from 'react-i18next';
import { useTheme } from './_layout';
import { themes } from '../src/design/tokens';

type Task = { id:string; title:string; description?:string; done:boolean; updatedAt?:string; deleted?:boolean };

export default function Home() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState('');
  const { t } = useTranslation();
  const { theme } = useTheme();
  const palette = themes[theme];

  const fetchTasks = async () => {
    try {
      const token = await getToken();
      const { data } = await axios.get(`${API_URL}/tasks`, { headers: { Authorization: `Bearer ${token}` } });
      setTasks(data);
    } catch {
      // offline - ignore
    }
  };

  const addTask = async () => {
    if (!title.trim()) return;
    const temp:Task = { id: 'local-'+Date.now(), title, done:false, updatedAt: new Date().toISOString() };
    setTasks([temp, ...tasks]);
    setTitle('');
    try {
      const token = await getToken();
      const { data } = await axios.post(`${API_URL}/tasks`, { title }, { headers: { Authorization: `Bearer ${token}` } });
      setTasks((prev)=> prev.map(x=> x.id===temp.id? data : x));
    } catch {
      await enqueue({ type: 'create', payload: { ...temp } });
    }
  };

  const toggle = async (item:Task) => {
    setTasks(ts=> ts.map(x=> x.id===item.id? {...x, done: !x.done} : x));
    try {
      const token = await getToken();
      await axios.post(`${API_URL}/tasks/${item.id}/toggle`, {}, { headers: { Authorization: `Bearer ${token}` } });
    } catch {
      await enqueue({ type: 'toggle', payload: { id: item.id } });
    }
  };

  const remove = async (item:Task) => {
    setTasks(ts=> ts.filter(x=> x.id!==item.id));
    try {
      const token = await getToken();
      await axios.delete(`${API_URL}/tasks/${item.id}`, { headers: { Authorization: `Bearer ${token}` } });
    } catch {
      await enqueue({ type: 'delete', payload: { id: item.id } });
    }
  };

  const syncNow = async () => {
    try {
      const token = await getToken();
      const queue = await drainQueue();
      // Replay locally queued ops
      for (const q of queue) {
        if (q.type==='create') {
          try {
            const { data } = await axios.post(`${API_URL}/tasks`, { title: q.payload.title }, { headers: { Authorization: `Bearer ${token}` } });
            setTasks(prev => prev.map(x => x.id===q.payload.id ? data : x));
          } catch {}
        } else if (q.type==='toggle') {
          try { await axios.post(`${API_URL}/tasks/${q.payload.id}/toggle`, {}, { headers: { Authorization: `Bearer ${token}` } }); } catch {}
        } else if (q.type==='delete') {
          try { await axios.delete(`${API_URL}/tasks/${q.payload.id}`, { headers: { Authorization: `Bearer ${token}` } }); } catch {}
        }
      }
      // Pull server changes since last sync
      const since = await getLastSyncAt();
      const pulled = await axios.get(`${API_URL}/sync`, { params: { since }, headers: { Authorization: `Bearer ${token}` } });
      const serverTasks:Task[] = pulled.data.tasks;
      const map = new Map<string, Task>();
      [...tasks, ...serverTasks].forEach(t => { map.set(t.id, { ...(map.get(t.id)||{} as any), ...t }); });
      setTasks(Array.from(map.values()).filter(t=>!t.deleted));
      await setLastSyncAt(pulled.data.ts);
    } catch (e:any) {
      Alert.alert('Sync error', e?.message || 'Failed to sync');
    }
  };

  useEffect(() => { fetchTasks(); }, []);

  return (
    <View style={{ flex:1, padding:16, backgroundColor: palette.bg }}>
      <Text style={{ color: palette.text, fontSize:22, fontWeight:'800', marginBottom:12 }}>{t('myTasks')}</Text>
      <View style={{ flexDirection:'row', marginBottom:12 }}>
        <TextInput style={{ flex:1, backgroundColor: palette.card, color: palette.text, padding:12, borderRadius:12, marginRight:8 }} placeholder={t('newTask') as string} placeholderTextColor="#AAB" value={title} onChangeText={setTitle}/>
        <TouchableOpacity style={{ backgroundColor:'#7AA2FF', paddingHorizontal:16, borderRadius:12, justifyContent:'center' }} onPress={addTask}><Text style={{ color: palette.bg, fontWeight:'700' }}>+</Text></TouchableOpacity>
        <TouchableOpacity style={{ marginLeft:8, borderColor:'#7AA2FF', borderWidth:1, paddingHorizontal:12, borderRadius:12, justifyContent:'center' }} onPress={syncNow}><Text style={{ color: palette.text }}>{t('sync')}</Text></TouchableOpacity>
      </View>
      <FlatList
        data={tasks}
        keyExtractor={(i)=>i.id}
        renderItem={({item}) => (
          <View style={{ flexDirection:'row', alignItems:'center', backgroundColor: palette.card, padding:12, borderRadius:12, marginBottom:8 }}>
            <TouchableOpacity style={{ marginRight:12 }} onPress={()=>toggle(item)}><Text style={{ color: palette.text }}>{item.done ? '[x]' : '[ ]'}</Text></TouchableOpacity>
            <Text style={{ flex:1, color: item.done ? '#9AA3B2' : palette.text, textDecorationLine: item.done ? 'line-through' : 'none' }}>{item.title}</Text>
            <TouchableOpacity onPress={()=>remove(item)}><Text style={{ color: palette.text }}>DEL</Text></TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}
