
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bgDark: "#0B1222",
        cardDark: "rgba(255,255,255,0.06)",
        textDark: "#E8ECF8",
        primary: "#7AA2FF",
        accent: "#A8FFCB",
        bgLight: "#F6F8FF",
        textLight: "#0B1222",
        cardLight: "rgba(0,0,0,0.06)"
      },
      borderRadius: { xl2: "1.25rem" }
    },
  },
  plugins: [],
}
