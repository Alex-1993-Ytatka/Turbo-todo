
export type ThemeName = 'dark' | 'light';
export const themes = {
  dark: { bg: '#0B1222', card: 'rgba(255,255,255,0.06)', text: '#E8ECF8' },
  light:{ bg: '#F6F8FF', card: 'rgba(0,0,0,0.06)', text: '#0B1222' }
};
export const colors = { primary:'#7AA2FF', accent:'#A8FFCB' };
