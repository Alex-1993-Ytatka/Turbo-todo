
import AsyncStorage from '@react-native-async-storage/async-storage';
export const API_URL = 'http://localhost:4000'; // Update for device/emulator
const TOKEN_KEY = 'token';
const QUEUE_KEY = 'offlineQueue';
const SYNC_TS = 'lastSyncAt';

export async function setToken(token:string) { await AsyncStorage.setItem(TOKEN_KEY, token); }
export async function getToken() { return AsyncStorage.getItem(TOKEN_KEY); }

export type QueueItem = { type:'create'|'update'|'delete'|'toggle', payload:any };
export async function enqueue(item:QueueItem) {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  const q:QueueItem[] = raw ? JSON.parse(raw) : [];
  q.push(item);
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(q));
}
export async function drainQueue():Promise<QueueItem[]> {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  const q:QueueItem[] = raw ? JSON.parse(raw) : [];
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify([]));
  return q;
}
export async function getLastSyncAt(){ return (await AsyncStorage.getItem(SYNC_TS)) || '1970-01-01T00:00:00.000Z'; }
export async function setLastSyncAt(ts:string){ await AsyncStorage.setItem(SYNC_TS, ts); }
